package fr.axephir.tnd.gametest;

import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import fr.axephir.tnd.city.*;
import fr.axephir.tnd.core.ModContent;
import fr.axephir.tnd.domain.Mastery;
import fr.axephir.tnd.narrative.*;
import fr.axephir.tnd.progression.*;
import fr.axephir.tnd.technology.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.core.*;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.level.*;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.storage.*;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Real native worlds, block entities, durable files and recovery transitions; never a mock destruction implementation. */
final class ConvergenceTests {
    static void register(DeferredRegister<Consumer<GameTestHelper>> f){
        f.register("anchor_energy",()->ConvergenceTests::anchorEnergy);f.register("anchor_limits",()->ConvergenceTests::anchorLimits);f.register("anchor_recovery",()->ConvergenceTests::anchorRecovery);
        f.register("piston_provenance",()->ConvergenceTests::piston);
        f.register("echo_journals",()->ConvergenceTests::journals);f.register("echo_reference",()->ConvergenceTests::reference);f.register("echo_copy",()->ConvergenceTests::copy);
        f.register("echo_respawn",()->ConvergenceTests::respawn);f.register("echo_camera",()->h->story(h,3));f.register("echo_return",()->h->story(h,0));f.register("echo_interrupt",()->h->story(h,1));f.register("echo_corruption",()->h->story(h,2));
        f.register("echo_observation",()->h->story(h,4));
        f.register("echo_choices",()->ConvergenceTests::choices);f.register("spatial_lens",()->ConvergenceTests::lens);f.register("rare_anomaly",()->ConvergenceTests::rare);
    }
    private static void check(GameTestHelper h,boolean b,String reason){h.assertTrue(b,Component.literal(reason));}
    @SuppressWarnings("deprecation") private static ServerLevel echo(GameTestHelper h){var server=h.getLevel().getServer();var existing=server.getLevel(Convergence.ECHO);if(existing!=null)return existing;
        try{
            LevelStem stem;try(var reader=server.getResourceManager().getResourceOrThrow(Identifier.fromNamespaceAndPath("tnd","dimension/aftermath.json")).openAsReader()){stem=LevelStem.CODEC.parse(RegistryOps.create(JsonOps.INSTANCE,server.registryAccess()),JsonParser.parseReader(reader)).getOrThrow();}
            var storage=LevelStorageSource.createDefault(Path.of("native-aftermath-fixtures")).createAccess(UUID.randomUUID().toString());
            var world=new ServerLevel(server,net.minecraft.util.Util.backgroundExecutor(),storage,new DerivedLevelData(server.getWorldData(),server.getWorldData().overworldData()),Convergence.ECHO,stem,false,1234,List.of(),false);server.forgeGetWorldMap().put(Convergence.ECHO,world);server.markWorldsDirty();
            NeoForge.EVENT_BUS.addListener((net.neoforged.neoforge.event.server.ServerStoppedEvent e)->{if(e.getServer()==server)try{storage.close();}catch(java.io.IOException failure){throw new java.io.UncheckedIOException(failure);}});return world;
        }catch(Exception e){throw new IllegalStateException("Cannot create isolated native aftermath level",e);}
    }
    private static void base(ServerLevel w,BlockPos at,boolean reactor){int r=reactor?2:1;for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)if(reactor?Math.max(Math.abs(x),Math.abs(z))==r:x!=0||z!=0)w.setBlock(at.offset(x,-1,z),Industry.FRAME.get().defaultBlockState(),2);
        for(int x:new int[]{-r,r})for(int z:new int[]{-r,r}){if(reactor)for(int y=0;y<3;y++)w.setBlock(at.offset(x,y,z),CityContent.DECOR.get("carbon_panel").get().defaultBlockState(),2);w.setBlock(at.offset(x,reactor?3:0,z),CityContent.DECOR.get("relay_coil").get().defaultBlockState(),2);}}
    private static SpatialAnchorEntity anchor(ServerLevel w,BlockPos at){w.setBlock(at,SpatialAnchors.BLOCK.get().defaultBlockState(),3);base(w,at,false);return (SpatialAnchorEntity)w.getBlockEntity(at);}
    private static void anchorEnergy(GameTestHelper h){var w=h.getLevel();var at=new BlockPos(210000,120,210000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at.south(3));var a=anchor(w,at);a.energy.set(6400);
        check(h,a.toggle(p)&&a.active()&&a.energy.getAmountAsInt()==6080,"A physical owned anchor pays exactly 320 FE for its first second");a.tick();check(h,a.energy.getAmountAsInt()==6080,"Repeated updates in one second do not consume duplicate energy");
        var atCrusher=at.east(5);w.setBlock(atCrusher,Industry.BLOCKS.get(Industry.Kind.CRUSHER).get().defaultBlockState(),3);base(w,atCrusher,false);var machine=(IndustrialEntity)w.getBlockEntity(atCrusher);machine.energy.set(10000);machine.setItem(0,new ItemStack(Items.RAW_IRON));
        FieldworkTests.release(w,at);var vestige=FieldworkTests.vestige(h);var away=new BlockPos(211000,120,211000);FieldworkTests.platform(vestige,away);p.teleport(new TeleportTransition(vestige,Vec3.atBottomCenterOf(away),Vec3.ZERO,0,0,TeleportTransition.DO_NOTHING));
        h.runAfterDelay(170,()->{try{check(h,a.active()&&w.shouldTickBlocksAt(new ChunkPos(at.getX()>>4,at.getZ()>>4).pack()),"Nine factory sectors remain native block-ticking with their owner in another dimension");check(h,machine.countItem(Industry.IRON_DUST.get())==2&&machine.getItem(0).isEmpty(),"A real crusher completes production while its owner explores another dimension");w.setBlock(at.north(),Blocks.REDSTONE_BLOCK.defaultBlockState(),3);a.tick();check(h,!a.active()&&a.status()==2,"A redstone signal releases the factory tickets immediately");}finally{a.release();GameplayTests.cleanup(p);FieldworkTests.release(vestige,away);}h.succeed();});
    }
    private static void anchorLimits(GameTestHelper h){var w=h.getLevel();var at=new BlockPos(212000,120,212000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at);var other=GameplayTests.player(h);var all=new ArrayList<SpatialAnchorEntity>();
        try{for(int x:new int[]{0,5,10}){var a=anchor(w,at.east(x));a.energy.set(10000);all.add(a);p.setPos(Vec3.atCenterOf(a.getBlockPos().south(2)));if(x<10)check(h,a.toggle(p),"Each owner can activate two real anchors");else check(h,!a.toggle(p)&&a.owner()==null,"A third anchor cannot steal a third owner slot");}
            other.setPos(p.position());check(h,!all.getFirst().toggle(other),"Another player cannot operate a claimed factory anchor");w.setBlock(at,Blocks.AIR.defaultBlockState(),3);check(h,!all.getFirst().active()&&SpatialAnchors.validate(p).size()==1,"Breaking an anchor releases tickets and prunes only that obsolete owner slot");check(h,all.getLast().toggle(p),"A newly freed owner slot can be used normally");
        }finally{all.forEach(SpatialAnchorEntity::release);GameplayTests.cleanup(p);GameplayTests.cleanup(other);FieldworkTests.release(w,at);}h.succeed();}
    private static void anchorRecovery(GameTestHelper h){var w=h.getLevel();var at=new BlockPos(214000,120,214000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at.south(3));var a=anchor(w,at);a.energy.set(10000);a.toggle(p);var saved=a.saveWithFullMetadata(w.registryAccess());var reload=(SpatialAnchorEntity)BlockEntity.loadStatic(at,a.getBlockState(),saved,w.registryAccess());
        check(h,reload.enabled()&&!reload.active()&&reload.owner().equals(p.getUUID())&&reload.energy.getAmountAsInt()==a.energy.getAmountAsInt(),"Native reload retains ownership and FE without resurrecting orphan tickets");
        GameplayTests.cleanup(p);check(h,!a.active(),"Owner logout releases factory tickets");a.tick();check(h,!a.active()&&a.status()==3,"An offline owner cannot reactivate tickets");FieldworkTests.release(w,at);h.succeed();}
    private static void piston(GameTestHelper h){
        var w=h.getLevel();var at=new BlockPos(216014,120,216000);FieldworkTests.platform(w,at);
        var p=FieldworkTests.player(h,w,at.south(3));var ore=at.east();int[] phase={0};long[] earned={0};boolean[] finished={false};
        Runnable cleanup=()->{GameplayTests.cleanup(p);FieldworkTests.release(w,at);};
        h.onEachTick(()->{
            if(phase[0]>=3)return;
            try{
                if(phase[0]==0){
                    // Forced-chunk futures are asynchronous. Power only after both
                    // sides of the real chunk boundary can process native block events.
                    if(!w.shouldTickBlocksAt(ChunkPos.pack(at))||!w.shouldTickBlocksAt(ChunkPos.pack(ore.east(2))))return;
                    w.setBlock(at,Blocks.STICKY_PISTON.defaultBlockState().setValue(PistonBaseBlock.FACING,Direction.EAST),3);
                    w.setBlock(ore,Blocks.IRON_ORE.defaultBlockState(),3);w.setBlock(ore.east(),Blocks.IRON_ORE.defaultBlockState(),3);
                    w.getChunkAt(ore).setData(ProgressionEvents.PLACED,List.of(ore.asLong()));
                    w.setBlock(at.above(),Blocks.REDSTONE_BLOCK.defaultBlockState(),3);phase[0]=1;return;
                }
                if(phase[0]==1){
                    // Check provenance as soon as both moving block entities finish,
                    // rather than treating twelve global ticks as twelve chunk ticks.
                    if(!w.getBlockState(ore.east()).is(Blocks.IRON_ORE)||!w.getBlockState(ore.east(2)).is(Blocks.IRON_ORE))return;
                    check(h,ProgressionEvents.playerPlaced(w,ore.east())&&!ProgressionEvents.playerPlaced(w,ore.east(2)),
                            "Settled native extension preserves placed/natural provenance across the chunk boundary: "+ProgressionEvents.playerPlaced(w,ore.east())+","+ProgressionEvents.playerPlaced(w,ore.east(2)));
                    p.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.DIAMOND_PICKAXE));long before=p.getData(PlayerProgression.PROFILE).get(Mastery.MINING).experience();
                    p.gameMode.destroyBlock(ore.east(2));earned[0]=p.getData(PlayerProgression.PROFILE).get(Mastery.MINING).experience();
                    check(h,earned[0]>before,"Moving a natural ore keeps its legitimate mining XP");
                    w.setBlock(at.above(),Blocks.AIR.defaultBlockState(),3);phase[0]=2;return;
                }
                if(!w.getBlockState(ore).is(Blocks.IRON_ORE))return;
                check(h,ProgressionEvents.playerPlaced(w,ore)&&!ProgressionEvents.playerPlaced(w,ore.east()),
                        "Settled sticky retraction preserves the placed marker: "+ProgressionEvents.playerPlaced(w,ore)+","+ProgressionEvents.playerPlaced(w,ore.east()));
                p.gameMode.destroyBlock(ore);check(h,p.getData(PlayerProgression.PROFILE).get(Mastery.MINING).experience()==earned[0],"A pushed then pulled placed ore still gives no mining XP");
                phase[0]=3;finished[0]=true;cleanup.run();
            }catch(RuntimeException failure){phase[0]=3;cleanup.run();throw failure;}
        });
        h.succeedWhen(()->check(h,finished[0],"Waiting for actual native piston motion: phase="+phase[0]+", piston="+w.getBlockState(at)+", source="+w.getBlockState(ore)+", destination="+w.getBlockState(ore.east())+", ticking="+w.shouldTickBlocksAt(ChunkPos.pack(at))+","+w.shouldTickBlocksAt(ChunkPos.pack(ore.east(2)))));
    }
    private static void journals(GameTestHelper h){var p=GameplayTests.player(h);try{var token=UUID.randomUUID();var reference=EchoReference.capture(p,token,p.blockPosition(),0);var path=Files.createTempDirectory("tnd-journal-test-");var journal=new EchoJournal(path);journal.prepare(reference);check(h,journal.read().equals(reference),"Two fsynced independent native NBT references verify exactly");Files.write(path.resolve("reference-a.nbt"),new byte[]{1,2,3});check(h,journal.read().equals(reference),"A corrupt first reference falls back to the independently verified second copy");Files.writeString(path.resolve("reference-b.sha256"),"0".repeat(64));boolean rejected=false;try{journal.read();}catch(java.io.IOException expected){rejected=true;}check(h,rejected&&Files.exists(path.resolve("reference-a.nbt"))&&Files.exists(path.resolve("reference-b.nbt")),"Both corrupt copies are rejected and retained for recovery");var blocked=path.resolve("unwritable");Files.writeString(blocked,"not a directory");rejected=false;try{new EchoJournal(blocked).prepare(reference);}catch(java.io.IOException expected){rejected=true;}check(h,rejected&&!Convergence.inEcho(p)&&!p.isSpectator(),"An incomplete/full-disk-style write prevents entry and leaves the source player unchanged");}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}finally{GameplayTests.cleanup(p);}h.succeed();}
    private static void reference(GameTestHelper h){var p=GameplayTests.player(h);try{p.getInventory().setItem(0,new ItemStack(Items.DIAMOND,7));p.setItemSlot(EquipmentSlot.CHEST,new ItemStack(Items.DIAMOND_CHESTPLATE));p.setItemSlot(EquipmentSlot.OFFHAND,new ItemStack(Items.TOTEM_OF_UNDYING));p.getEnderChestInventory().setItem(17,new ItemStack(Items.NETHERITE_INGOT,5));p.giveExperiencePoints(537);p.getFoodData().setFoodLevel(13);p.setHealth(11);var token=UUID.randomUUID();var tag=EchoReference.capture(p,token,p.blockPosition(),3);EchoReference.validate(tag,p.getUUID(),token);p.getInventory().clearContent();p.getEnderChestInventory().clearContent();p.setHealth(20);p.giveExperiencePoints(5000);EchoReference.restoreResources(p,tag);
        check(h,p.getInventory().getItem(0).getCount()==7&&p.getItemBySlot(EquipmentSlot.CHEST).is(Items.DIAMOND_CHESTPLATE)&&p.getOffhandItem().is(Items.TOTEM_OF_UNDYING),"Round trip retains all native inventory slots including equipped armour and offhand");check(h,p.getEnderChestInventory().getItem(17).getCount()==5&&p.totalExperience==537&&p.getFoodData().getFoodLevel()==13&&p.getHealth()==11,"Ender inventory, exact XP, food and health are restored");boolean rejected=false;try{EchoReference.validate(tag,UUID.randomUUID(),token);}catch(IllegalArgumentException expected){rejected=true;}check(h,rejected,"A reference owned by another player cannot be accepted");
        }finally{GameplayTests.cleanup(p);}h.succeed();}
    private static void copy(GameTestHelper h){var w=h.getLevel();var destination=echo(h);var at=new BlockPos(220000,120,220000);FieldworkTests.platform(w,at);w.setBlock(at,ConvergenceContent.RESTORER.get().defaultBlockState(),3);var chestAt=at.east(2);w.setBlock(chestAt,Blocks.CHEST.defaultBlockState(),3);var chest=(ChestBlockEntity)w.getBlockEntity(chestAt);chest.setItem(4,new ItemStack(Items.DIAMOND,27));var atBattery=at.west(2);w.setBlock(atBattery,Industry.BLOCKS.get(Industry.Kind.BATTERY).get().defaultBlockState(),3);var battery=(IndustrialEntity)w.getBlockEntity(atBattery);battery.energy.set(87432);var saved=chest.saveWithFullMetadata(w.registryAccess());var energySaved=battery.saveWithFullMetadata(w.registryAccess());var rooftop=new BlockPos(at.getX()+2,w.getMaxY(),at.getZ()+3);w.setBlock(rooftop,Blocks.DIAMOND_BLOCK.defaultBlockState(),3);var upper=at.offset(12,15,0);var falling=at.offset(12,14,8);w.setBlock(upper,Blocks.STONE.defaultBlockState(),3);w.setBlock(falling,Blocks.GOLD_BLOCK.defaultBlockState(),3);var task=new EchoCopyTask(w,destination,at,1000,0);task.step();
        h.succeedWhen(()->{check(h,task.finished(),"Native echo relighting completes");check(h,chest.saveWithFullMetadata(w.registryAccess()).equals(saved)&&battery.saveWithFullMetadata(w.registryAccess()).equals(energySaved),"Copying leaves source chest NBT and exact machine energy/inventory unchanged");var copied=destination.getBlockEntity(task.mapped(chestAt));check(h,copied instanceof ChestBlockEntity c&&c.isEmpty(),"The isolated visual chest contains no copied valuables");check(h,destination.getBlockEntity(task.mapped(atBattery))==null&&destination.getBlockState(task.mapped(at)).is(ConvergenceContent.RESTORER.get()),"Technology is inert wreckage; only the empty restorer remains");check(h,destination.getBlockState(task.mapped(upper)).isAir()&&w.getBlockState(upper).is(Blocks.STONE),"Upper building floors are visibly breached only in the isolated copy");check(h,destination.getBlockState(task.mapped(rooftop)).is(Blocks.DIAMOND_BLOCK)&&w.getBlockState(rooftop).is(Blocks.DIAMOND_BLOCK),"Copying includes the native build-height limit and leaves its source intact");check(h,!destination.getBlockState(task.mapped(falling)).isAir(),"A copied upper facade exists before its cinematic collapse");task.cinematicImpact(0);check(h,destination.getBlockState(task.mapped(falling)).isAir()&&w.getBlockState(falling).is(Blocks.GOLD_BLOCK)&&destination.getBlockState(task.mapped(at)).is(ConvergenceContent.RESTORER.get()),"A real bounded cinematic collapse changes echo blocks while preserving the source facade and restorer");FieldworkTests.release(w,at);});}
    private static void story(GameTestHelper h,int lane){var w=h.getLevel();echo(h);var at=new BlockPos(224000+lane*128,120,224000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at.south(3));var reactor=at.west(8);w.setBlock(at,ConvergenceContent.RESTORER.get().defaultBlockState(),3);base(w,at,false);w.setBlock(reactor,ConvergenceContent.REACTOR.get().defaultBlockState(),3);base(w,reactor,true);p.setPos(Vec3.atBottomCenterOf(reactor.south(3)));p.setData(Codex.NOTES,255);p.getInventory().setItem(0,new ItemStack(Items.DIAMOND,3));p.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.DIAMOND_HELMET));p.getEnderChestInventory().setItem(3,new ItemStack(Items.GOLD_INGOT,5));var marker=at.south(5);w.setBlock(marker,Blocks.GOLD_BLOCK.defaultBlockState(),3);boolean[] started={false},entered={false};int[] cameraTicks={0};
        h.onEachTick(()->{
            if(!started[0]){if(Convergence.begin(p,reactor,0)){started[0]=true;p.getInventory().getItem(0).setCount(2);}return;}
            NeoForge.EVENT_BUS.post(new PlayerTickEvent.Post(p));
            if(lane==3&&Convergence.inEcho(p)&&p.getData(Convergence.PHASE)==2){if(cameraTicks[0]++<30)return;
                check(h,p.getCamera()!=p&&p.level().shouldTickBlocksAt(ChunkPos.pack(p.getCamera().blockPosition())),"The actual spectator camera stays in a temporarily ticking native chunk");check(h,p.getCamera().getViewVector(1).dot(Vec3.atCenterOf(Convergence.echoMachine(p)).subtract(p.getCamera().position()).normalize())>.999,"The native camera view, including the living entity head rotation, looks towards the damaged base during its orbit");var point=p.getCamera().position();
                check(h,p.teleport(new TeleportTransition(p.level(),p.position(),Vec3.ZERO,p.getYRot(),p.getXRot(),TeleportTransition.DO_NOTHING))!=null,"Scene protection allows same-dimension camera movement");
                Convergence.finishCinema(p);check(h,p.position().distanceToSqr(point)<.01&&p.getCamera()==p,"Camera handoff keeps its real final position, instead of returning inside a source wall");entered[0]=true;check(h,Convergence.recover(p),"A camera session still recovers normally");return;
            }
            if(entered[0]||!Convergence.inEcho(p))return;entered[0]=true;
            check(h,p.isSpectator()&&w.getBlockState(marker).is(Blocks.GOLD_BLOCK),"The catastrophe switches only its owner to an isolated read-only projection; source remains intact");
            if(lane==4){
                Convergence.finishCinema(p);var core=Convergence.echoMachine(p);p.setPos(core.getX()+.5,core.getY(),core.getZ()+3.5);p.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES,Vec3.atCenterOf(core));
                check(h,Convergence.inspect(p)&&p.getData(Convergence.TRACES)==8&&p.containerMenu instanceof ConvergenceMenu,"The owner's real ray hears a trace and opens the personal core: hit="+p.pick(6,1,false)+" traces="+p.getData(Convergence.TRACES)+" phase="+p.getData(Convergence.PHASE)+" menu="+p.containerMenu.getClass().getSimpleName());
                p.closeContainer();check(h,!Convergence.inspect(p),"Repeated private inspection obeys its server cooldown");
                p.setData(Convergence.TRACES,4);var provider=p.level().getBlockState(core).getMenuProvider(p.level(),core);check(h,provider!=null,"The personal core exposes the real vanilla spectator menu provider");p.openMenu(provider);
                check(h,p.getData(Convergence.TRACES)==12&&p.containerMenu instanceof ConvergenceMenu,"Vanilla spectator menu opening records the core trace even when its packet arrives before custom inspection");p.closeContainer();
                var other=GameplayTests.player(h);try{check(h,!Convergence.inspect(other)&&other.getData(Convergence.TRACES)==0,"An unrelated player cannot inspect another owner's projection");}finally{GameplayTests.cleanup(other);}
                h.runAfterDelay(32,()->{
                    var floor=core.south(2).below();p.level().setBlock(floor,ModContent.ASHSTONE_BRICKS.get().defaultBlockState(),3);p.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES,Vec3.atCenterOf(floor));
                    check(h,Convergence.inspect(p)&&p.getData(Convergence.TRACES)==12,"Looking at an actual stone floor records a material trace, never an imaginary machine display");
                    check(h,Convergence.recover(p),"Interactive exploration retains safe personal recovery");
                });
            }else if(lane==0){Convergence.finishCinema(p);var restorer=Convergence.echoMachine(p);var menu=new ConvergenceMenu(75,p.getInventory(),p,restorer,false);var other=GameplayTests.player(h);try{check(h,!menu.select(other,1)&&menu.select(p,2)&&Convergence.inEcho(p),"Foreign restore choices are rejected and refusing keeps the ruins available");}finally{GameplayTests.cleanup(other);}w.setBlock(marker,Blocks.IRON_BLOCK.defaultBlockState(),3);p.getInventory().setItem(9,new ItemStack(Items.EMERALD,64));for(var floor:BlockPos.betweenClosed(reactor.offset(-39,-1,-39),reactor.offset(39,-1,39)))w.setBlock(floor,Blocks.LAVA.defaultBlockState(),2);
                check(h,Convergence.requestRestoration(p),"The owner can accept restoration after refusing");
                h.runAfterDelay(35,()->{check(h,Convergence.inEcho(p)&&p.getData(Convergence.PHASE)==4,"A blocked source returns to exploration instead of trapping the player behind a permanent restoration fade");w.setBlock(reactor.south(3).below(),Blocks.STONE.defaultBlockState(),3);check(h,Convergence.requestRestoration(p),"Restoration can be retried after clearing only the original arrival floor");});}
            else{String token=p.getData(Convergence.RETURN).split(";")[0];var journal=new EchoJournal(w.getServer(),p.getUUID(),UUID.fromString(token));NeoForge.EVENT_BUS.post(new PlayerEvent.PlayerLoggedOutEvent(p));try{Files.write(journal.directory().resolve("reference-a.nbt"),new byte[]{1,2,3});if(lane==1){Files.write(journal.directory().resolve("reference-b.nbt"),new byte[]{4,5,6});p.setData(Convergence.PHASE,5);}else{p.setData(Convergence.RETURN,"");StoryRecords.get(w.getServer()).phase(p.getUUID(),0);}}catch(java.io.IOException e){throw new java.io.UncheckedIOException(e);}NeoForge.EVENT_BUS.post(new PlayerEvent.PlayerLoggedInEvent(p));}
        });
        h.succeedWhen(()->{check(h,entered[0]&&!Convergence.inEcho(p)&&p.getData(Convergence.PHASE)==6,"Projection return: lane="+lane+" started="+started[0]+" entered="+entered[0]+" phase="+p.getData(Convergence.PHASE)+" ready="+Convergence.readiness(p,reactor)+" progress="+Convergence.progress(p)+" pos="+p.position()+" dim="+p.level().dimension().identifier());try{check(h,p.level()==w&&!p.isSpectator()&&p.getData(Convergence.FINISHED),"Return restores the source dimension, game mode and endgame progression");check(h,p.getInventory().getItem(0).getCount()==2&&p.getInventory().countItem(Items.EMERALD)==0&&p.getItemBySlot(EquipmentSlot.HEAD).is(Items.DIAMOND_HELMET)&&p.getEnderChestInventory().getItem(3).getCount()==5,"Transition snapshot includes preparation-time changes, preserves armour/ender slots and discards temporary resources");check(h,w.getBlockState(marker).is(lane==0?Blocks.IRON_BLOCK:Blocks.GOLD_BLOCK),"Restoration never rewinds another player's legitimate source-world construction");check(h,!Convergence.recover(p),"A completed recovery index cannot replay an old inventory restoration");}finally{GameplayTests.cleanup(p);FieldworkTests.release(w,at);}});
    }
    private static void respawn(GameTestHelper h){var w=h.getLevel();echo(h);var at=new BlockPos(224700,120,224000);FieldworkTests.platform(w,at);var initial=FieldworkTests.player(h,w,at.south(3));var reactor=at.west(8);w.setBlock(at,ConvergenceContent.RESTORER.get().defaultBlockState(),3);base(w,at,false);w.setBlock(reactor,ConvergenceContent.REACTOR.get().defaultBlockState(),3);base(w,reactor,true);initial.setPos(Vec3.atBottomCenterOf(reactor.south(3)));initial.setData(Codex.NOTES,255);initial.getInventory().setItem(0,new ItemStack(Items.DIAMOND,7));
        ServerPlayer[] current={initial};boolean[] started={false},recreated={false};
        h.onEachTick(()->{var p=current[0];if(!started[0]){started[0]=Convergence.begin(p,reactor,0);return;}if(recreated[0])return;NeoForge.EVENT_BUS.post(new PlayerTickEvent.Post(p));if(!Convergence.inEcho(p))return;
            Convergence.finishCinema(p);p.getInventory().clearContent();current[0]=w.getServer().getPlayerList().respawn(p,false,net.minecraft.world.entity.Entity.RemovalReason.KILLED);current[0].connection.player=current[0];recreated[0]=true;
        });
        h.succeedWhen(()->{var p=current[0];check(h,recreated[0]&&!Convergence.inEcho(p)&&p.getData(Convergence.PHASE)==6,"A genuine native respawn pipeline recovers an interrupted projection");try{check(h,p.level()==w&&!p.isSpectator()&&p.getInventory().countItem(Items.DIAMOND)==7,"Cloned player attachments recover lost temporary inventory from the verified pre-scene reference");}finally{GameplayTests.cleanup(p);FieldworkTests.release(w,at);}});
    }
    private static void choices(GameTestHelper h){var w=h.getLevel();var at=new BlockPos(225000,120,225000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at);var q=GameplayTests.player(h);w.setBlock(at,ConvergenceContent.REACTOR.get().defaultBlockState(),3);base(w,at,true);
        try{var menu=new ConvergenceMenu(40,p.getInventory(),p,at,true);check(h,!menu.select(p,0)&&!menu.select(q,0)&&!menu.select(p,-1)&&!menu.select(p,999),"Native readiness and owner checks reject missing archives, forged owners and arbitrary action indices");p.setData(Codex.NOTES,255);check(h,Convergence.readiness(p,at)==4&&!menu.select(p,0),"Even eight archives cannot start without the real nearby restorer assembly");}finally{GameplayTests.cleanup(p);GameplayTests.cleanup(q);FieldworkTests.release(w,at);}h.succeed();}
    private static void lens(GameTestHelper h){var w=h.getLevel();var at=new BlockPos(226000,120,226000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at);var other=GameplayTests.player(h);
        try{check(h,!SpatialLensItem.reissue(p),"The fourth-axis lens cannot be obtained before the narrative conclusion");p.setData(Convergence.FINISHED,true);check(h,SpatialLensItem.reissue(p),"A completed player receives an individually bound lens");var lens=p.getInventory().getItem(0).copy();check(h,!SpatialLensItem.valid(other,lens)&&SpatialLensItem.activate(p,lens,false)&&!SpatialLensItem.activate(p,lens,false),"Borrowed lenses fail; genuine perception respects the native shared cooldown");check(h,p.getData(Convergence.PERCEPTION)==w.getGameTime()+300,"Perception lasts precisely fifteen seconds");check(h,!SpatialLensItem.reissue(p),"A present bound lens cannot be duplicated through its reward menu");p.getInventory().setItem(0,ItemStack.EMPTY);check(h,SpatialLensItem.reissue(p)&&!SpatialLensItem.valid(p,lens),"Reissue revokes copied or lost old lens keys");var next=p.getInventory().getItem(0);p.getCooldowns().removeCooldown(p.getCooldowns().getCooldownGroup(next));p.setYRot(-90);p.setXRot(0);w.setBlock(at.east(4),Blocks.STONE.defaultBlockState(),3);check(h,SpatialLensItem.activate(p,next,true)&&p.getX()>at.getX()+5&&p.distanceToSqr(Vec3.atBottomCenterOf(at))<65,"Spatial step crosses a wall onto native safe loaded ground, within eight blocks");}finally{GameplayTests.cleanup(p);GameplayTests.cleanup(other);FieldworkTests.release(w,at);}h.succeed();}
    private static void rare(GameTestHelper h){var w=FieldworkTests.vestige(h);var at=new BlockPos(227000,120,227000);FieldworkTests.platform(w,at);var p=FieldworkTests.player(h,w,at);var q=GameplayTests.player(h);try{p.tickCount=200;NeoForge.EVENT_BUS.post(new PlayerTickEvent.Post(p));long next=p.getData(RareAnomalies.NEXT),now=w.getServer().overworld().getGameTime();check(h,next>=now+12000&&next<=now+36000,"First private anomaly is scheduled ten to thirty minutes ahead");p.setData(RareAnomalies.NEXT,now-1);NeoForge.EVENT_BUS.post(new PlayerTickEvent.Post(p));check(h,p.getData(RareAnomalies.SEQUENCE)==1&&q.getData(RareAnomalies.SEQUENCE)==0&&p.getData(RareAnomalies.NEXT)>=now+36000,"A genuine scheduled anomaly affects only its owner and waits thirty minutes before another event");var out=TagValueOutput.createWithContext(ProblemReporter.DISCARDING,w.registryAccess());p.saveWithoutId(out);var clone=new ServerPlayer(w.getServer(),w,p.getGameProfile(),p.clientInformation());clone.load(TagValueInput.create(ProblemReporter.DISCARDING,w.registryAccess(),out.buildResult()));check(h,clone.getData(RareAnomalies.NEXT).equals(p.getData(RareAnomalies.NEXT)),"Relogging retains the rare-event schedule");}finally{GameplayTests.cleanup(p);GameplayTests.cleanup(q);FieldworkTests.release(w,at);}h.succeed();}
    private ConvergenceTests(){}
}
