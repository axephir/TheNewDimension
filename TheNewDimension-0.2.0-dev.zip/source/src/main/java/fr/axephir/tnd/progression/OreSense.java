package fr.axephir.tnd.progression;

import fr.axephir.tnd.domain.*;
import fr.axephir.tnd.technology.ExtractorBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;

public final class OreSense {
    /** Scans loaded blocks only; the active talent does not reveal remote chunks. */
    public static int scan(ServerPlayer player, Mastery mastery) {
        if (mastery != Mastery.MINING && mastery != Mastery.LOGGING && mastery != Mastery.ENGINEERING) return 0;
        var progress = player.getData(PlayerProgression.PROFILE).get(mastery);
        if (progress.rank(Talent.INSIGHT) == 0) {
            player.sendOverlayMessage(Component.translatable("message.tnd.sense_locked")); return 0;
        }
        // A server-owned cooldown cannot be bypassed by switching held items.
        long now = player.level().getGameTime();
        if (now < player.getData(PlayerProgression.SENSE_NEXT_TICK)) return 0;
        player.setData(PlayerProgression.SENSE_NEXT_TICK, now + 100);
        int radius = 6 + 2 * progress.rank(Talent.PRECISION);
        BlockPos origin = player.blockPosition(), best = null;
        double distance = Double.POSITIVE_INFINITY;
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -radius, -radius), origin.offset(radius, radius, radius))) {
            if (!player.level().hasChunk(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            var state = player.level().getBlockState(pos);
            boolean matches = switch (mastery) {
                case MINING -> ProgressionEvents.isOre(state);
                case LOGGING -> state.is(BlockTags.LOGS);
                case ENGINEERING -> player.level().getBlockEntity(pos) instanceof ExtractorBlockEntity;
                default -> false;
            };
            double candidate = pos.distSqr(origin);
            if (matches && candidate < distance) { best = pos.immutable(); distance = candidate; }
        }
        if (best == null) player.sendOverlayMessage(Component.translatable("message.tnd.sense_empty"));
        else player.sendOverlayMessage(Component.translatable("message.tnd.sense_found", Math.round(Math.sqrt(distance)),
                best.getY() > origin.getY() + 2 ? Component.translatable("direction.tnd.above")
                        : best.getY() < origin.getY() - 2 ? Component.translatable("direction.tnd.below")
                        : Component.translatable("direction.tnd.level")));
        return best == null ? 0 : 1;
    }
    private OreSense() {}
}
