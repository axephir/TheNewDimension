package fr.axephir.tnd.technology;

import fr.axephir.tnd.core.*;
import fr.axephir.tnd.domain.*;
import fr.axephir.tnd.progression.PlayerProgression;
import net.minecraft.core.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.*;

/** Three physical slots: fuel, tuning module, output. No hidden infinite resource store. */
public final class ExtractorBlockEntity extends BlockEntity implements Container, MenuProvider {
    private final NonNullList<ItemStack> items = NonNullList.withSize(3, ItemStack.EMPTY);
    private long lastTick = -1;
    private long progress;
    private int calibration;
    private int synergy;
    private boolean settling;
    public final ContainerData data = new ContainerData() {
        @Override public int get(int index) {
            return switch (index) { case 0 -> (int) (progress * 1000 / period()); case 1 -> period(); default -> 0; };
        }
        @Override public void set(int index, int value) {}
        @Override public int getCount() { return 2; }
    };

    public ExtractorBlockEntity(BlockPos pos, BlockState state) { super(MachineRegistry.EXTRACTOR_ENTITY.get(), pos, state); }
    private int period() {
        double speed = 1 + calibration / 100.0 + synergy * 0.02;
        if (items.get(1).is(ModContent.EFFICIENCY_MODULE.get())) speed += 0.5;
        return Math.max(20, (int) (TndConfig.EXTRACTOR_TICKS.getAsInt() / speed));
    }
    public void tune(Player player) {
        settle();
        var profile = player.getData(PlayerProgression.PROFILE);
        var engineering = profile.get(Mastery.ENGINEERING);
        calibration = engineering.rank(Talent.EFFICIENCY) * 5 + engineering.rank(Talent.YIELD) * 3
                + engineering.rank(Talent.PRECISION);
        synergy = Math.min(profile.get(Mastery.ENGINEERING).rank(Talent.SYNERGY), profile.get(Mastery.MINING).rank(Talent.SYNERGY));
        setChanged();
    }

    public void settle() {
        if (settling || level == null || level.isClientSide()) return;
        settling = true;
        try {
            long now = Math.max(0, level.getGameTime());
            if (lastTick < 0) { lastTick = now; setChanged(); return; }
            ItemStack fuel = items.get(0), output = items.get(2);
            if ((!output.isEmpty() && !output.is(Items.RAW_IRON))
                    || (!fuel.isEmpty() && !validFuel(fuel))) { lastTick = now; progress = 0; return; }
            var result = Production.advance(new Production.State(lastTick, progress, fuel.getCount(), output.getCount()),
                    new Production.Rules(period(), 1, 64, TndConfig.MAX_CATCHUP.getAsInt()), now);
            int made = result.output() - output.getCount();
            fuel.shrink(fuel.getCount() - result.fuel());
            if (made > 0) {
                if (output.isEmpty()) items.set(2, new ItemStack(Items.RAW_IRON, made));
                else output.grow(made);
            }
            lastTick = result.lastTick(); progress = result.progressTicks();
            setChanged();
        } finally { settling = false; }
    }
    public static boolean validFuel(ItemStack stack) { return stack.is(Items.COAL) || stack.is(Items.CHARCOAL); }
    @Override public int getContainerSize() { return 3; }
    @Override public boolean isEmpty() { settle(); return items.stream().allMatch(ItemStack::isEmpty); }
    @Override public ItemStack getItem(int slot) { settle(); return items.get(slot); }
    @Override public ItemStack removeItem(int slot, int amount) {
        settle(); var result = ContainerHelper.removeItem(items, slot, amount); setChanged(); return result;
    }
    @Override public ItemStack removeItemNoUpdate(int slot) { settle(); return ContainerHelper.takeItem(items, slot); }
    @Override public void setItem(int slot, ItemStack stack) {
        settle(); stack.limitSize(slot == 1 ? 1 : 64); items.set(slot, stack); setChanged();
    }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == 0 ? validFuel(stack) : slot == 1 && stack.is(ModContent.EFFICIENCY_MODULE.get());
    }
    @Override public void clearContent() { settle(); items.clear(); setChanged(); }
    @Override public boolean stillValid(Player player) {
        return level != null && level.getBlockEntity(worldPosition) == this
                && player.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 64;
    }
    @Override public Component getDisplayName() { return Component.translatable("block.tnd.extractor"); }
    @Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        settle(); return new ExtractorMenu(id, inventory, this, data);
    }
    @Override public void preRemoveSideEffects(BlockPos pos, BlockState state) {
        if (level != null && !level.isClientSide()) {
            settle();
            Containers.dropContents(level, pos, this);
            items.clear();
        }
        super.preRemoveSideEffects(pos, state);
    }
    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putLong("lastTick", lastTick); output.putLong("progress", progress);
        output.putInt("calibration", calibration); output.putInt("synergy", synergy);
        var list = output.list("items", ItemStackWithSlot.CODEC);
        for (int slot = 0; slot < 3; slot++) if (!items.get(slot).isEmpty()) list.add(new ItemStackWithSlot(slot, items.get(slot)));
    }
    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        lastTick = input.getLongOr("lastTick", -1); progress = Math.max(0, input.getLongOr("progress", 0));
        calibration = Math.clamp(input.getIntOr("calibration", 0), 0, 45);
        synergy = Math.clamp(input.getIntOr("synergy", 0), 0, 5);
        items.clear();
        input.listOrEmpty("items", ItemStackWithSlot.CODEC).forEach(entry -> {
            if (entry.isValidInContainer(3)) items.set(entry.slot(), entry.stack());
        });
    }
}
