package fr.axephir.tnd.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import fr.axephir.tnd.technology.ExtractorMenu;

public final class ExtractorScreen extends AbstractContainerScreen<ExtractorMenu> {
    public ExtractorScreen(ExtractorMenu menu,Inventory inventory,Component title){super(menu,inventory,title);}
    @Override protected void extractLabels(GuiGraphicsExtractor g,int x,int y) {}
    @Override public void extractBackground(GuiGraphicsExtractor g,int mouseX,int mouseY,float partial){
        int x=leftPos,y=topPos;
        StonePanel.frame(g,x,y,imageWidth,imageHeight);
        g.text(font,title,x+9,y+7,0xff30382c,false);
        StonePanel.inset(g,x+8,y+20,160,53);
        label(g,Component.translatable("gui.tnd.extractor.fuel"),x+35,y+25);
        label(g,Component.translatable("gui.tnd.extractor.module"),x+79,y+25);
        label(g,Component.translatable("gui.tnd.extractor.output"),x+133,y+25);
        for(int sx:new int[]{27,71,125})StonePanel.slot(g,x+sx,y+43);
        g.fill(x+96,y+46,x+118,y+55,0xff19271e);
        int fill=menu.progress()*22/1000;
        g.fill(x+96,y+47,x+96+fill,y+54,0xff9bb665);
        g.fill(x+114,y+44,x+116,y+57,0xffa8af95);
        g.fill(x+116,y+46,x+118,y+55,0xffa8af95);
        g.text(font,Component.translatable("gui.tnd.extractor.period",menu.period()/20),x+14,y+63,0xffc6d0b8,false);
        g.text(font,Component.translatable("container.inventory"),x+8,y+75,0xff394232,false);
        for(int r=0;r<3;r++)for(int c=0;c<9;c++)StonePanel.slot(g,x+8+c*18,y+84+r*18);
        for(int c=0;c<9;c++)StonePanel.slot(g,x+8+c*18,y+142);
    }
    private void label(GuiGraphicsExtractor g,Component text,int center,int y) {
        g.text(font,text,center-font.width(text)/2,y,0xffd2dbc3,false);
    }
}
