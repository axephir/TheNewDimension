package fr.axephir.tnd.progression;

import com.mojang.serialization.Codec;
import fr.axephir.tnd.core.*;
import fr.axephir.tnd.domain.*;
import fr.axephir.tnd.technology.MachineRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import java.util.*;

/** Awards are server-side and only follow successful manual harvests. */
public final class ProgressionEvents {
    @SubscribeEvent
    public void crafted(PlayerEvent.ItemCraftedEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.isCreative()) return;
        boolean machine = event.getCrafting().is(MachineRegistry.EXTRACTOR.get().asItem())
                || event.getCrafting().is(ModContent.EFFICIENCY_MODULE.get());
        if (!machine) return;
        long amount = Math.round(40 * Math.max(1, event.getCrafting().getCount()) * TndConfig.XP_MULTIPLIER.get());
        if (amount > 0) player.setData(PlayerProgression.PROFILE,
                player.getData(PlayerProgression.PROFILE).award(Mastery.ENGINEERING, amount));
    }
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<List<Long>>> PLACED =
            PlayerProgression.TYPES.register("placed_resources", () -> AttachmentType.<List<Long>>builder(() -> List.of())
                    .serialize(Codec.LONG.listOf().fieldOf("positions")).build());

    public static boolean isOre(BlockState state) {
        return state.is(net.neoforged.neoforge.common.Tags.Blocks.ORES)
                || state.is(ModContent.BLUE_ORE.get()) || state.is(ModContent.RED_ORE.get())
                || state.is(ModContent.GREEN_ORE.get()) || state.is(ModContent.RESONANT_ORE.get());
    }

    @SubscribeEvent
    public void placed(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        BlockState state = event.getPlacedBlock();
        if (!isOre(state) && !state.is(BlockTags.LOGS)) return;
        var chunk = player.level().getChunkAt(event.getPos());
        var positions = new HashSet<>(chunk.getData(PLACED));
        positions.add(event.getPos().asLong());
        chunk.setData(PLACED, List.copyOf(positions));
    }

    @SubscribeEvent
    public void harvested(BlockDropsEvent event) {
        if (!(event.getBreaker() instanceof ServerPlayer player) || player.isCreative()
                || event.getDrops().isEmpty() || event.isCanceled()) return;
        var chunk = event.getLevel().getChunkAt(event.getPos());
        var positions = new HashSet<>(chunk.getData(PLACED));
        if (positions.remove(event.getPos().asLong())) {
            chunk.setData(PLACED, List.copyOf(positions));
            return;
        }
        Mastery mastery = event.getState().is(BlockTags.LOGS) ? Mastery.LOGGING
                : isOre(event.getState()) ? Mastery.MINING : null;
        if (mastery == null) return;
        Profile profile = player.getData(PlayerProgression.PROFILE);
        long xp = Math.round((mastery == Mastery.MINING ? 20 : 8) * TndConfig.XP_MULTIPLIER.get());
        if (xp > 0) player.setData(PlayerProgression.PROFILE, profile.award(mastery, xp));
        // Bonus respects vanilla drops (including enchantments), but is capped at one item per harvest.
        double chance = profile.get(mastery).rank(Talent.YIELD) * 0.02;
        if (player.getRandom().nextDouble() < chance) {
            var first = event.getDrops().getFirst();
            var extra = first.getItem().copyWithCount(1);
            event.getDrops().add(new net.minecraft.world.entity.item.ItemEntity(event.getLevel(),
                    first.getX(), first.getY(), first.getZ(), extra));
        }
    }

    @SubscribeEvent
    public void speed(PlayerEvent.BreakSpeed event) {
        Mastery mastery = event.getState().is(BlockTags.LOGS) ? Mastery.LOGGING
                : isOre(event.getState()) ? Mastery.MINING : null;
        if (mastery == null) return;
        var progress = event.getEntity().getData(PlayerProgression.PROFILE).get(mastery);
        var engineering = event.getEntity().getData(PlayerProgression.PROFILE).get(Mastery.ENGINEERING);
        double multiplier = 1 + progress.rank(Talent.EFFICIENCY) * 0.05 + Experience.prestigeBonus(progress.level())
                + Math.min(progress.rank(Talent.SYNERGY), engineering.rank(Talent.SYNERGY)) * 0.02;
        event.setNewSpeed((float) (event.getNewSpeed() * multiplier));
    }
}
