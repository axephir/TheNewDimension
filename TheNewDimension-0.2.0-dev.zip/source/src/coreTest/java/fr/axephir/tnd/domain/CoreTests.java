package fr.axephir.tnd.domain;

import java.util.*;

/** Dependency-free regression runner; every assertion throws even without -ea. */
public final class CoreTests {
    private static int assertions;
    public static void main(String[] args) {
        progression(); profiles(); production(); cycle();
        System.out.println("PASS: " + assertions + " assertions (progression, saves, production, cycle)");
    }
    private static void check(boolean value, String reason) {
        assertions++;
        if (!value) throw new AssertionError(reason);
    }
    private static void rejects(Runnable action) {
        assertions++;
        try { action.run(); } catch (IllegalArgumentException | IllegalStateException expected) { return; }
        throw new AssertionError("expected rejection");
    }
    private static void progression() {
        check(Mastery.values().length == 15, "fifteen independent masteries");
        check(Experience.level(0) == 1, "initial level");
        for (int level = 2; level < 10_000; level++) {
            long threshold = Experience.threshold(level);
            check(Experience.level(threshold - 1) == level - 1, "lower boundary " + level);
            check(Experience.level(threshold) == level, "exact boundary " + level);
        }
        check(Experience.earnedPoints(100) == 99, "main progression");
        check(Experience.earnedPoints(109) == 99, "prestige interval");
        check(Experience.earnedPoints(110) == 100, "prestige point");
        check(Experience.level(Long.MAX_VALUE) > 1_000_000, "no level 100 cap");
        check(Experience.add(Long.MAX_VALUE - 2, 10) == Long.MAX_VALUE, "overflow safe XP");
        check(Experience.prestigeBonus(1_000_000) < 0.05, "bounded prestige");
        rejects(() -> Experience.add(1, -1));
        rejects(() -> Experience.level(-1));
        var p = MasteryProgress.empty();
        rejects(() -> MasteryProgress.empty().learn(Talent.EFFICIENCY));
        p = p.award(Experience.threshold(100));
        rejects(() -> MasteryProgress.empty().award(Experience.threshold(100)).learn(Talent.INSIGHT));
        for (var talent : Talent.values())
            for (int rank = 0; rank < talent.maxRank(); rank++) p = p.learn(talent);
        check(p.points() == 44, "all talents obtainable without exclusivity");
        MasteryProgress full = p;
        rejects(() -> full.learn(Talent.YIELD));
        check(Profile.empty().award(Mastery.MINING, 250).get(Mastery.LOGGING).experience() == 0,
                "independent progression");
    }
    private static void profiles() {
        var p = Profile.empty();
        for (var m : Mastery.values()) p = p.award(m, Experience.threshold(110));
        p = p.with(Mastery.MINING, p.get(Mastery.MINING).learn(Talent.EFFICIENCY).learn(Talent.INSIGHT));
        check(Profile.decode(p.encode()).equals(p), "save roundtrip including talents");
        check(Profile.decode(p.encode()).encode().equals(p.encode()), "deterministic encoding");
        check(Profile.decode(Profile.empty().encode()).equals(Profile.empty()), "empty save");
        rejects(() -> Profile.decode("not base64!"));
        rejects(() -> Profile.decode("A".repeat(16_385)));
        byte[] raw = Base64.getDecoder().decode(p.encode());
        raw[3] = 99;
        rejects(() -> Profile.decode(Base64.getEncoder().encodeToString(raw)));
        rejects(() -> new MasteryProgress(0, Map.of(Talent.YIELD, 1)));
        rejects(() -> new MasteryProgress(0, Map.of(Talent.EFFICIENCY, 1)));
    }
    private static void production() {
        var rules = new Production.Rules(100, 2, 64, 432_000);
        var state = new Production.State(0, 0, 100, 0);
        var next = Production.advance(state, rules, 1_050);
        check(next.output() == 10 && next.fuel() == 80 && next.progressTicks() == 50, "catch-up accounting");
        check(Production.advance(next, rules, 1_050).equals(next), "repeated catch-up is idempotent");
        var full = Production.advance(state, rules, Long.MAX_VALUE);
        check(full.output() == 50 && full.fuel() == 0 && full.progressTicks() == 0, "fuel limits absence production");
        var capped = Production.advance(new Production.State(0, 0, 1_000, 63), rules, 1_000);
        check(capped.output() == 64 && capped.fuel() == 998, "inventory limits production");
        check(capped.progressTicks() == 0, "no stored backlog at capacity");
        var noFuel = Production.advance(new Production.State(0, 90, 0, 0), rules, 10_000);
        check(noFuel.output() == 0 && noFuel.progressTicks() == 0, "no retroactive fuel credit");
        check(Production.advance(new Production.State(10_000, 90, 8, 0), rules, 1).progressTicks() == 0,
                "clock rollback never grants production");
        var limit = Production.advance(new Production.State(0, 0, 1_000_000, 0),
                new Production.Rules(100, 1, 1_000_000, 1_000), 50_000);
        check(limit.output() == 10, "bounded catch-up workload");
        Random random = new Random(843124);
        for (int i = 0; i < 10_000; i++) {
            int fuel = random.nextInt(128), output = random.nextInt(65);
            var input = new Production.State(100, random.nextInt(100), fuel, output);
            var actual = Production.advance(input, rules, 100 + random.nextInt(50_000));
            check(actual.output() >= output && actual.output() <= 64, "output invariant");
            check(actual.fuel() >= 0 && actual.fuel() <= fuel, "fuel invariant");
            check((actual.output() - output) * 2 == fuel - actual.fuel(), "resource conservation");
        }
        // A reload must match continuous ticking while resources remain available.
        var repeated = state;
        for (int tick = 1; tick <= 3_000; tick++) repeated = Production.advance(repeated, rules, tick);
        check(repeated.equals(Production.advance(state, rules, 3_000)), "loaded/unloaded equivalence");
    }
    private static void cycle() {
        var cycle = new DimensionCycle(48_000);
        check(cycle.isDay(0) && cycle.isDay(23_999), "twenty-minute day");
        check(!cycle.isDay(24_000) && !cycle.isDay(47_999), "twenty-minute night");
        check(cycle.isDay(48_000), "cycle rollover");
        check(cycle.vanillaVisualTime(24_000) == 12_000, "visual phase");
        rejects(() -> new DimensionCycle(7));
    }
}
